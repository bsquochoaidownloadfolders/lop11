var ad = 'div[align="center"], #toPopup, #backgroundPopup, #previewad'
$("head").append("<style>"+ad+"{display:none !important;} </style>")
$(ad).remove()